<footer >
   <div class="py-3 px-4 mt-4 text-center text-md-right opacity-5">
   &copy; 
   <?php $year = date("Y"); ?>
   {{$year}} - {{config('app.name')}} 
   </div>
</footer>