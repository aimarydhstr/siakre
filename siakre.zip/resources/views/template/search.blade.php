
<form action="{{route('search')}}" method="get" class="form-inline justify-content-end mb-4 mt-2 search">
   <input class="mr-3" type="search" placeholder="Pencarian Nama / NIM / Tahun" name="search">
   <button class="search" type="submit"><i  class="fas fa-search" aria-hidden="true"></i></button>
</form>