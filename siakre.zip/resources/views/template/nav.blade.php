<nav class="navbar navbar-expand navbar-light bg-light fixed-top navbar-sticky">
  <div class="container-fluid">
    <div id="menu-toggle">
      <div id="nav-icon1">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
          @if($user=="NULL")
            <a class="nav-link" href="{{route('login')}}">
              LOGIN
            </a>
          @else
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              {{$user->name}}
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item text-danger" href="{{route('logout')}}"><i class="fas fa-power-off mr-1"></i> Logout</a>
            </div>
          @endif
        </li>
      </ul>
    </div>
  </div>
</nav>
